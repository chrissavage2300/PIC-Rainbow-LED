/**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This is the main file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.7
        Device            :  PIC16F1574
        Driver Version    :  2.00
*/
#define _XTAL_FREQ 8000000
/*

*/

#include "mcc_generated_files/mcc.h"
#include "mcc_generated_files/mcc.h"    //NOTE HAD TO ADD THIS.
#include "mcc_generated_files/pin_manager.h"
#include <stdio.h>
#include <xc.h>
/*
                         Main application
 * PWM1 is GREEN
 * PWM2 is RED
 * PWM3 is BLUE
 * Duty cycle set is 0 to 4000 counts
 * PWM has to be stopped initially, then we can send a duty cycle. 
 */

int Green_Fade_In;
int Green_Fade_Out;    
int Green_MIN =1;
int Green_MAX=160;

int Blue_Fade_In;
int Blue_Fade_Out;
int Blue_MIN =1;
int Blue_MAX=160;

int Red_Fade_In;
int Red_Fade_Out;
int Red_MIN =1;
int Red_MAX=160;

int All_colors_in;
int All_colors_out;
int All_Colors_min =1;
int All_Colors_max=160;

void Green_FadeIn_Cycle ()
{

        for (Green_Fade_In=Green_MIN;Green_Fade_In<Green_MAX;Green_Fade_In=Green_Fade_In+4)
    {
        PWM1_DutyCycleSet(Green_Fade_In);
        PWM1_LoadBufferSet();
       __delay_ms(250);  

    }
    
}
void Green_FadeOut_cycle()
{          
    for (Green_Fade_Out=Green_MAX;Green_Fade_Out>Green_MIN;Green_Fade_Out=Green_Fade_Out-4)
    {
        PWM1_DutyCycleSet(Green_Fade_Out);
        PWM1_LoadBufferSet();
       __delay_ms(250);                        
    }   
    
}
void Blue_FadeIn_Cycle()
{
    
    for (Blue_Fade_In=Blue_MIN;Blue_Fade_In<Blue_MAX;Blue_Fade_In=Blue_Fade_In+4)
    {
        PWM3_DutyCycleSet(Blue_Fade_In);
        PWM3_LoadBufferSet();
       __delay_ms(250);  

    }    
    
}
void Blue_FadeOut_Cycle()
{       
     for (Blue_Fade_Out=Blue_MAX;Blue_Fade_Out>Blue_MIN;Blue_Fade_Out=Blue_Fade_Out-4)
    {
        PWM3_DutyCycleSet(Blue_Fade_Out);
        PWM3_LoadBufferSet();
       __delay_ms(250);                        
    }     
    
}
void Red_FadeIn_Cycle()
{       
    
     for (Red_Fade_In=Red_MIN;Red_Fade_In<Red_MAX;Red_Fade_In=Red_Fade_In+4)
    {
        PWM2_DutyCycleSet(Red_Fade_In);
        PWM2_LoadBufferSet();
       __delay_ms(250);  

    }   
}
void Red_FadeOut_Cycle()
{       
     for (Red_Fade_Out=Red_MAX;Red_Fade_Out>Red_MIN;Red_Fade_Out=Red_Fade_Out-4)
    {
        PWM2_DutyCycleSet(Red_Fade_Out);
        PWM2_LoadBufferSet();
       __delay_ms(250);                        
    } 
    
}
void All_colors_FadeIn()
{
    PWM1_Start();   //start green
    PWM2_Start();   //start red
    PWM3_Start();   //start blue 
    for (All_colors_in=All_Colors_min;All_colors_in<All_Colors_max;All_colors_in=All_colors_in+4)
    {
        PWM1_DutyCycleSet(All_colors_in);
        PWM2_DutyCycleSet(All_colors_in);
        PWM3_DutyCycleSet(All_colors_in);
        PWM1_LoadBufferSet();
        PWM2_LoadBufferSet();
        PWM3_LoadBufferSet();
        __delay_ms(250);
    }
    
    
}

void All_colors_FadeOut()
{
    for (All_colors_out=All_Colors_max;All_colors_out>All_Colors_min;All_colors_out=All_colors_out-4)
    {
        PWM1_DutyCycleSet(All_colors_out);
        PWM2_DutyCycleSet(All_colors_out);
        PWM3_DutyCycleSet(All_colors_out);
        PWM1_LoadBufferSet();
        PWM2_LoadBufferSet();
        PWM3_LoadBufferSet();
        __delay_ms(250);
    }
    
    PWM1_Stop();   //stop red
    PWM2_Stop();   //stop green
    PWM3_Stop();   //stop blue 
}

void RGB_Separate_Cycle()
{
        PWM1_Stop();
        PWM2_Start();
        PWM3_Stop();
        
        Red_FadeIn_Cycle();
        Red_FadeOut_Cycle();

        PWM2_Stop();
        PWM3_Stop();         
       __delay_ms(1000);//delay inbetween cycles
        PWM1_Start();
        
        Green_FadeIn_Cycle();
        Green_FadeOut_cycle();
        PWM1_Stop();        
        PWM2_Stop();
        
        __delay_ms(1000);//delay inbetween cycles

        PWM3_Start();        
        Blue_FadeIn_Cycle();
        Blue_FadeOut_Cycle();            

        PWM3_Stop();    //stop blue 
        
       __delay_ms(1000);//delay inbetween cycles   
    
}

void Alt_Fade_In_out()
{//this sequence brings up red,then green,then blue
 //then fades out green,blue,and finally red
 //basically all colors fade in and then fade out in reverse order
       PWM2_Start();   //start red
       Red_FadeIn_Cycle();
       PWM1_Start();   //start green
       Green_FadeIn_Cycle();
       PWM3_Start();
       Blue_FadeIn_Cycle();
       Green_FadeOut_cycle();
       PWM1_Stop(); //stop green
       Blue_FadeOut_Cycle();        
       PWM3_Stop();    //stop blue  
       Red_FadeOut_Cycle();       
       PWM2_Stop(); //stop red  
}

void Color_Wheel_Fade_In_Out()
{
    /*this loop follows the color wheel
     * Red Fades in, holds, while green fades in slowly
     * Red then fades out while green holds
     * Blue then fades in while green holds
     * Green then fades out while blue holds
     * Red then fades in while Blue holds
     * Blue fades out while red holds
     * Finally, the loop ends with red fading out
    */
       PWM2_Start();   //start red  
       Red_FadeIn_Cycle();       
       PWM1_Start();   //start green       
       Green_FadeIn_Cycle();       
       Red_FadeOut_Cycle();       
       PWM2_Stop(); //stop red
       PWM3_Start();    //start blue       
       Blue_FadeIn_Cycle();
       Green_FadeOut_cycle();       
       PWM1_Stop(); //stop green
       PWM2_Start(); //start red       
       Red_FadeIn_Cycle();
       Blue_FadeOut_Cycle();        
       PWM3_Stop();    //stop blue       
       Red_FadeOut_Cycle();       
       PWM2_Stop(); //stop red 
 
    
}

void main(void)
{
    // initialize the device
//    * PWM1 is GREEN
//    * PWM2 is RED
//    * PWM3 is BLUE
    SYSTEM_Initialize(); 
    PWM1_Stop();   //stop red
    PWM2_Stop();   //stop green
    PWM3_Stop();   //stop blue 

    while (1)
    {    
//       if (LOWBATT_GetValue() == 0)//check to see if the battery is low before running.
//                                   //loop will still run if battery becomes low during loop process.
//                                   //SET FOR 0 FOR NOW
//       {
        Color_Wheel_Fade_In_Out(); 
        __delay_ms(1000);//delay inbetween cycles
        Alt_Fade_In_out(); 
//       }
//       else{
//            PWM1_Stop();   //stop green
//            PWM2_Stop();   //stop red
//            PWM3_Stop();   //stop blue
//            PWM2_Start();
//            PWM2_DutyCycleSet(400);
//            PWM2_LoadBufferSet();
//            __delay_ms(250);
//            PWM2_DutyCycleSet(0);
//            PWM2_LoadBufferSet();
//            __delay_ms(250);
           
//       }
       
       
          
      
    }
    
}  



/**
 End of File
*/